package com.cg.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.service.AccountService;


public class AccountTest {
	private AccountDAO mock;
	private AccountService service;
	@Before
	public void setup(){
		service=new AccountService();
		mock=EasyMock.createMock(AccountDAO.class);
		service.setDao(mock);
	}
	@Test
	public void testLogin() {
		int aid=101;
		String ah="Shahrukh";
		long mno=1234567890;
		double bal=5000.0;
		Account ac=new Account(aid,mno,ah,bal);
		
		EasyMock.expect(mock.findAccount(mno)).andReturn(ac);
		EasyMock.replay(mock);
		assertNotNull(service.findAccount(mno));
		EasyMock.verify(mock);
	}
}
