package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.cg.bean.Account;
import com.cg.dao.AccountDAOImpl;
import com.cg.service.AccountService;

class WalletTest {

	static AccountDAOImpl dao;
	static AccountService service;
	@Test
	public static void beforeallTest() {
		System.out.println("Before All Test");
		dao=new AccountDAOImpl();
		service=new AccountService();
	}
	
	@Test
	void addTest() {
		Account ac=new Account();
		ac.setAid(101);
		ac.setAccountholder("Shahrukh");
		ac.setBalance(2000.0);
		ac.setMobile(1234657890);
		assertTrue(dao.addAccount(ac));
	}

	@Test
	void updatetest() {
		Account ac=new Account(101,1234567890,"shahrukh",2500);
		assertTrue(dao.updateAccount(ac));
		System.out.println("Update tested");
	}
	
	
}
