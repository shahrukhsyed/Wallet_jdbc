package com.cg.service;

public interface Validator {
	String aidpattern="[1-9][0-9][0-9]";                                   //pattern for Account ID (must be a 3 digit number)
	String mobilepattern="[1-9]{1}[0-9]{9}";                               //pattern for Account holder's mobile number (must be a 10 digit number)
	String namepattern="[a-zA-Z][a-zA-Z]*+['||.]*+[a-z]*+[ ]*+[a-zA-Z]*";  //pattern for Account holder name 
	String balancepattern="[1-9][0-9][0-9][0-9][0-9]*[.]*[0-9]*";          //pattern for Account holder balance (must be numeric)
	
	
	//  Function for validating pattern
	public static boolean validatedata(String data,String pattern){
		return data.matches(pattern);
	}
}