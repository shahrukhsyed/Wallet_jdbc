package com.cg.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Service.AccountService;
import com.cg.entities.Account;
import com.cg.inputFormats.DepositAndWithdraw;
import com.cg.inputFormats.TransferFundFormat;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	AccountService service;

	Account a1 = new Account(101, "1234567896", "Shahrukh", 20000.0);
	Account a2 = new Account(102, "9876543212", "Ankish", 10000.0);
	Account a3 = new Account(103, "6549871236", "Harshita", 7500.0);

	@PostConstruct
	public void populate() {
		// creating dummy accounts
		service.addAccount(a1);
		service.addAccount(a2);
		service.addAccount(a3);
	}

	@GetMapping(value = "")
	public List<Account> getAll() {
		// to view all the available accounts

		return service.getAllAccounts();
	}

	@GetMapping(value = "find/{id}")
	public Account findById(@PathVariable int id) {
		// to find a account by id

		return service.findAccount(id);
	}

	@PostMapping(value = "/new", consumes = { "application/json" })
	public String addAccount(@RequestBody Account account) {
		// to save a new account

		service.addAccount(account);
		return "Account added successfully!";
	}

	@PutMapping(value = "update/{id}", consumes = { "application/json" })
	public String update(@RequestBody Account account, @PathVariable int id) {
		// to update an existing account

		service.update(id, account);
		;
		return "Account Updated successfully...";
	}

	@DeleteMapping(value = "delete/{id}")
	public String delete(@PathVariable int id) {
		// to delete an existing account

		Account a = service.findAccount(id);
		service.deleteAccount(a);
		return "Account Deleted successfully";
	}

	@PutMapping(value = "/withdraw", consumes = { "application/json" })
	public double withdraw(@RequestBody DepositAndWithdraw input) {
		// Withdrawing amount

		Account a = service.findAccount(input.getId());
		double amount = input.getAmount();

		return service.withdraw(a, amount);
	}

	@PutMapping(value = "/deposit", consumes = { "application/json" })
	public double deposit(@RequestBody DepositAndWithdraw input) {
		// Depositing amount

		Account a = service.findAccount(input.getId());
		double amount = input.getAmount();

		return service.deposit(a, amount);
	}

	@PutMapping(value = "/transfer", consumes = { "application/json" })
	public double[] transferMoney(@RequestBody TransferFundFormat input) {

		// Transferring amount between 2 accounts using IDs

		int id1 = input.getId1();
		int id2 = input.getId2();
		double amount = input.getAmount();

		Account from = service.findAccount(id1);
		Account to = service.findAccount(id2);

		return service.transferMoney(from, to, amount);
	}

}
