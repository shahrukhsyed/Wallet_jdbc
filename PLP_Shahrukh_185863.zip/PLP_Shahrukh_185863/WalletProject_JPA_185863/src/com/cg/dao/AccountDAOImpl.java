package com.cg.dao;

import java.sql.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import com.cg.jpa.entity.Account;
import com.cg.exception.InsufficientFundException;
import javax.persistence.*;

public class AccountDAOImpl implements AccountDAO {

	static ConcurrentHashMap<Long, Account> accamp = new ConcurrentHashMap<Long, Account>();

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");

	EntityManager em = emf.createEntityManager();

	// Adding Account
	@Override
	public boolean addAccount(Account ob) throws SQLException {
		accamp.put(ob.getMobile_No(), ob);
		int id = ob.getAccount_Id();
		Long mb = ob.getMobile_No();
		String ah = ob.getAccount_Holder();
		double bal = ob.getAccount_Balance();

		em.getTransaction().begin();
		Account account = new Account();
		account.setAccount_Id(id);
		account.setMobile_No(mb);
		account.setAccount_Holder(ah);
		account.setAccount_Balance(bal);
		em.persist(account);
		em.flush();
		System.out.println("Account added\n" + "ID: " + account.getAccount_Id() + ", Mobile no. : "
				+ account.getMobile_No() + ", Account Holder Name: " + account.getAccount_Holder() + ", Balance: "
				+ account.getAccount_Balance());
		em.getTransaction().commit();

		return true;

	}

	// Updating Account Details
	@Override
	public boolean updateAccount(Long mb, double amount) throws SQLException {
		Account account = em.find(Account.class, mb);

		em.getTransaction().begin();
		account.setAccount_Balance(amount);
		em.merge(account);
		System.out.println("Account Updated for Mobile Number :: " + account.getMobile_No());
		em.getTransaction().commit();

		return true;
	}

	// Deleting Account
	@Override
	public boolean deleteAccount(Long mb) throws SQLException {

		Account account = em.find(Account.class, mb);
		account.getMobile_No();
		em.getTransaction().begin();
		em.remove(account);
		System.out.println("Account Deleted Successfully !!");
		em.getTransaction().commit();

		return true;
	}

	// Finding Account
	@Override
	public Account findAccount(Long mb) throws SQLException {

		Account account = em.find(Account.class, mb);
		account.getAccount_Id();
		account.getMobile_No();
		account.getAccount_Holder();
		account.getAccount_Balance();
		return account;
	}

	// Displaying All Accounts
	@SuppressWarnings("unchecked")
	@Override
	public List<Account> getAllAccounts() {
		em.getTransaction().begin();
		Query q = em.createQuery("select a from Account a");
		em.getTransaction().commit();
		return q.getResultList();
	}

	// Transferring Money
	@Override
	public boolean TransferMoney(Long from, Long to, double amount) throws InsufficientFundException, SQLException {

		Account account1 = em.find(Account.class, from);
		double bal = account1.getAccount_Balance() - amount;
		updateAccount(from, bal);

		Account account2 = em.find(Account.class, to);
		bal = account2.getAccount_Balance() + amount;

		updateAccount(to, bal);

		return true;
	}

}
