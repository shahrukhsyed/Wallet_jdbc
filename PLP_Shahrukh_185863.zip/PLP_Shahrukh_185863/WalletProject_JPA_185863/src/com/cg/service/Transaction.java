package com.cg.service;

import java.sql.SQLException;
import com.cg.jpa.entity.Account;
import com.cg.exception.InsufficientFundException;

public interface Transaction extends AccountOperation {

	public boolean withdraw(Long mb, double amount) throws InsufficientFundException, SQLException;

	public boolean deposit(Long mb, double amount) throws SQLException;

	public boolean TransferMoney(Long from, Long to, double amount) throws InsufficientFundException, SQLException;

	public default void printStatement(Account ob) {
		System.out.println("========== ACCOUNT-STATEMENT ==============");
		System.out.println(" Account No => " + ob.getAccount_Id());
		System.out.println(" Account Holder Name => " + ob.getAccount_Holder());
		System.out.println(" Mobile number => " + ob.getMobile_No());
		System.out.println(" Balance => " + ob.getAccount_Balance());
		System.out.println("============================================");
	}

}
