package com.cg.service;

import java.sql.SQLException;
import java.util.List;
import com.cg.jpa.entity.Account;
import com.cg.exception.InsufficientFundException;

public interface AccountOperation {

	public boolean addAccount(Account ob) throws SQLException;

	public boolean deleteAccount(Long mb) throws SQLException;

	public Account findAccount(Long mb) throws SQLException;

	public boolean updateAccount(Long mb, double amount) throws SQLException;

	public List<Account> getAllAccounts() throws SQLException;

	public boolean TransferMoney(Long from, Long to, double amount) throws InsufficientFundException, SQLException;

}
