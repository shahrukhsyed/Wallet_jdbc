package com.cg.service;

import java.sql.*;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.jpa.entity.Account;
import com.cg.dao.*;
import com.cg.exception.InsufficientFundException;

public class AccountService implements Gst, Transaction {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");

	EntityManager em = emf.createEntityManager();

	AccountDAO dao = new AccountDAOImpl();

	// Function for withdrawing money from account
	@Override
	public boolean withdraw(Long mb, double amount) throws InsufficientFundException, SQLException {

		Account account = em.find(Account.class, mb);
		double bal = account.getAccount_Balance() - amount;

		if (bal < 100.00) {
			bal = account.getAccount_Balance();
			throw new InsufficientFundException("Insufficient Fund. Can't process withdrawl", bal);
		}

		return dao.updateAccount(mb, bal);

	}

	// Function for depositing money
	@Override
	public boolean deposit(Long mb, double amount) throws SQLException {
		Account account = em.find(Account.class, mb);
		double bal = account.getAccount_Balance() + amount;

		return dao.updateAccount(mb, bal);
	}

	// Function for calculating Tax
	@Override
	public double calculateTax(double PCT, double amount) {
		return amount * Gst.PCT_5;
	}

	// Function for adding Account
	@Override
	public boolean addAccount(Account ob) throws SQLException {
		return dao.addAccount(ob);
	}

	// Function for Deleting Account
	@Override
	public boolean deleteAccount(Long mb) throws SQLException {
		return dao.deleteAccount(mb);
	}

	// Function for Getting all Account
	@Override
	public List<Account> getAllAccounts() throws SQLException {
		return dao.getAllAccounts();
	}

	// Function for updating Account
	@Override
	public boolean updateAccount(Long mb, double amount) throws SQLException {
		return dao.updateAccount(mb, amount);
	}

	// Function for Transferring Money Between 2 accounts
	@Override
	public boolean TransferMoney(Long from, Long to, double amount) throws InsufficientFundException, SQLException {
		return dao.TransferMoney(from, to, amount);
	}

	// Function for finding Account
	@Override
	public Account findAccount(Long mb) throws SQLException {
		return dao.findAccount(mb);
	}

}
