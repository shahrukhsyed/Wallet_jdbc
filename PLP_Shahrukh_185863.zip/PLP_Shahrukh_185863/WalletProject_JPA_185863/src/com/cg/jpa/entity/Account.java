package com.cg.jpa.entity;

import javax.persistence.*;

@Entity
@Table(name = "wallet_account") // Table name => wallet_account
public class Account {

	@Column(length = 10)
	private int Account_Id;
	@Id
	@Column(length = 10)
	private long Mobile_No;
	@Column(length = 20)
	private String Account_Holder;
	@Column(length = 20)
	private double Account_Balance;

	// Default constructor
	public Account() {
		
	}

	// Parameterized Constructor
	public Account(int account_Id, long mobile_No, String account_Holder, double account_Balance) {
		super();
		Account_Id = account_Id;
		Mobile_No = mobile_No;
		Account_Holder = account_Holder;
		Account_Balance = account_Balance;
	}
	//to String method
	@Override
	public String toString() {
		return "Account [Account_Id=" + Account_Id + ", Mobile_No=" + Mobile_No + ", Account_Holder=" + Account_Holder
				+ ", Account_Balance=" + Account_Balance + "]";
	}

	// Getters & Setters
	public int getAccount_Id() {
		return Account_Id;
	}

	public void setAccount_Id(int account_Id) {
		Account_Id = account_Id;
	}

	public long getMobile_No() {
		return Mobile_No;
	}

	public void setMobile_No(long mobile_No) {
		Mobile_No = mobile_No;
	}

	public String getAccount_Holder() {
		return Account_Holder;
	}

	public void setAccount_Holder(String account_Holder) {
		Account_Holder = account_Holder;
	}

	public double getAccount_Balance() {
		return Account_Balance;
	}

	public void setAccount_Balance(double account_Balance) {
		Account_Balance = account_Balance;
	}

}
