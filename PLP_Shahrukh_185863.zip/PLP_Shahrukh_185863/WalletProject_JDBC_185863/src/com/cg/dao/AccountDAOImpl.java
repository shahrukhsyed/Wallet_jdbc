package com.cg.dao;

import java.sql.*;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.bean.Account;
import com.cg.exception.InsufficientFundException;

public class AccountDAOImpl implements AccountDAO {
	Connection con = JdbcConnection.getConnection();
	static ConcurrentHashMap<Long, Account> accamp = new ConcurrentHashMap<Long, Account>();

	// Adding Account
	@Override
	public boolean addAccount(Account ob) throws SQLException {
		accamp.put(ob.getMobile(), ob);
		int id = ob.getAid();
		Long mb = ob.getMobile();
		String ah = ob.getAccountholder();
		double bal = ob.getBalance();
		String sqlQuery = "insert into account_jdbc values(?,?,?,?)";

		PreparedStatement st = con.prepareStatement(sqlQuery);
		st.setInt(1, id);
		st.setLong(2, mb);
		st.setString(3, ah);
		st.setDouble(4, bal);

		int insertedRec = st.executeUpdate();
		System.out.println("Inserted Records:- " + insertedRec);

		con.commit();

		return true;

	}

	// Updating Account Details
	@Override
	public boolean updateAccount(int id, double amount) throws SQLException {
		PreparedStatement updateSt = con.prepareStatement("update account_jdbc set balance=? where aid=?");

		updateSt.setDouble(1, amount);
		updateSt.setInt(2, id);
		int i1 = updateSt.executeUpdate();
		System.out.println("Account updated" + i1);
		con.commit();

		return true;
	}

	// Deleting Account
	@Override
	public boolean deleteAccount(int id) throws SQLException {
		PreparedStatement selectSt = con.prepareStatement("delete from account_jdbc where aid=?");
		selectSt.setInt(1, id);
		@SuppressWarnings("unused")
		ResultSet rs1 = selectSt.executeQuery();
		System.out.println("Account deleted");

		con.commit();

		return true;
	}

	// Finding Account
	@Override
	public Account findAccount(int id) throws SQLException {
		@SuppressWarnings("unlikely-arg-type")
		Account ob = accamp.get(id);
		PreparedStatement selectSt = con.prepareStatement("select * from account_jdbc where aid=?");
		selectSt.setInt(1, id);
		ResultSet rs1 = selectSt.executeQuery();
		while (rs1.next()) {
			double bal = rs1.getDouble(4);
			System.out.println(" Balance:-" + bal);
			System.out.println("================================");
		}

		return ob;
	}

	// Displaying All Accounts

	@Override
	public ConcurrentHashMap<Long, Account> getAllAccount() throws SQLException {
		Statement st = con.createStatement();// used to pass SQL queries

		/// to display records..........
		ResultSet rs = st.executeQuery("select * from account_jdbc");
		while (rs.next()) {
			int a_id = rs.getInt("aid"); // column name or column position............
			long mobile = rs.getLong(2);
			String ah = rs.getString(3);
			double bal = rs.getDouble(4);
			System.out.println(
					"Account id:- " + a_id + ", Mobile No:- " + mobile + ", Name:- " + ah + ", Balance:-" + bal);
			System.out.println("================================");
		}

		return accamp;
	}

	// Transferring Money
	@Override
	public boolean TransferMoney(int from, int to, double amount) throws InsufficientFundException, SQLException {
		double bal = 0.0;
		PreparedStatement selectSt = con.prepareStatement("select * from account_jdbc where aid=?");
		selectSt.setInt(1, from);
		ResultSet rs1 = selectSt.executeQuery();
		while (rs1.next()) {
			bal = rs1.getDouble(4);
			bal = bal - amount;
		}
		updateAccount(from, bal);

		selectSt = con.prepareStatement("select * from account_jdbc where aid=?");
		selectSt.setInt(1, to);
		rs1 = selectSt.executeQuery();
		while (rs1.next()) {
			bal = rs1.getDouble(4);
			bal = bal + amount;
		}
		updateAccount(to, bal);

		return true;
	}

}
