package com.cg.dao;

import com.cg.bean.*;
import com.cg.exception.InsufficientFundException;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

public interface AccountDAO {

	public boolean addAccount(Account ob) throws SQLException;

	public boolean updateAccount(int id, double amount) throws SQLException;

	public boolean deleteAccount(int id) throws SQLException;

	public Account findAccount(int id) throws SQLException;

	public ConcurrentHashMap<Long, Account> getAllAccount() throws SQLException;

	public boolean TransferMoney(int from, int to, double amount) throws InsufficientFundException, SQLException;

}
