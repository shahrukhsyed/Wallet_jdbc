package com.cg.service;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.bean.*;
import com.cg.dao.*;

import com.cg.exception.InsufficientFundException;

public class AccountService implements Gst, Transaction {
	Connection con = JdbcConnection.getConnection();
	AccountDAO dao = new AccountDAOImpl();

	// Function for withdrawing money from account
	@Override
	public boolean withdraw(int id, double amount) throws InsufficientFundException, SQLException {
		double bal = 0.0;
		PreparedStatement selectSt = con.prepareStatement("select * from account_jdbc where aid=?");
		selectSt.setInt(1, id);
		ResultSet rs1 = selectSt.executeQuery();
		while (rs1.next()) {
			bal = rs1.getDouble(4);
			bal = bal - amount;
		}
		return dao.updateAccount(id, bal);

	}

	// Function for depositing money
	@Override
	public boolean deposit(int id, double amount) throws SQLException {
		double bal = 0.0;
		PreparedStatement selectSt = con.prepareStatement("select * from account_jdbc where aid=?");
		selectSt.setInt(1, id);
		ResultSet rs1 = selectSt.executeQuery();
		while (rs1.next()) {
			bal = rs1.getDouble(4);
			bal = bal + amount;
		}
		return dao.updateAccount(id, bal);
	}

	// Function for calculating Tax
	@Override
	public double calculateTax(double PCT, double amount) {
		return amount * Gst.PCT_5;
	}

	// Function for adding Account
	@Override
	public boolean addAccount(Account ob) throws SQLException {
		return dao.addAccount(ob);
	}

	// Function for Deleting Account
	@Override
	public boolean deleteAccount(int id) throws SQLException {
		return dao.deleteAccount(id);
	}

	// Function for Getting all Account
	@Override
	public ConcurrentHashMap<Long, Account> getAllAccount() throws SQLException {
		return dao.getAllAccount();
	}

	// Function for updating Account
	@Override
	public boolean updateAccount(int id, double amount) throws SQLException {
		return dao.updateAccount(id, amount);
	}

	// Function for Transferring Money Between 2 accounts
	@Override
	public boolean TransferMoney(int from, int to, double amount) throws InsufficientFundException, SQLException {
		return dao.TransferMoney(from, to, amount);
	}

	// Function for finding an Account
	@Override
	public Account findAccount(int id) throws SQLException {
		return dao.findAccount(id);
	}

}
