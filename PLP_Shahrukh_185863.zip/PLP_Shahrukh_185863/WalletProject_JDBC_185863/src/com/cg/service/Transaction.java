package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.*;
import com.cg.exception.InsufficientFundException;

public interface Transaction extends AccountOperation {

	public boolean withdraw(int id, double amount) throws InsufficientFundException, SQLException;

	public boolean deposit(int id, double amount) throws SQLException;

	public boolean TransferMoney(int from, int to, double amount) throws InsufficientFundException, SQLException;

	public default void printStatement(Account ob) {
		System.out.println("=========Account-Statement===============");
		System.out.println("Account Number => " + ob.getAid());
		System.out.println("Account holder name => " + ob.getAccountholder());
		System.out.println("Mobile number => " + ob.getMobile());
		System.out.println("Balance => " + ob.getBalance());
		System.out.println("=========================================");
	}

}
