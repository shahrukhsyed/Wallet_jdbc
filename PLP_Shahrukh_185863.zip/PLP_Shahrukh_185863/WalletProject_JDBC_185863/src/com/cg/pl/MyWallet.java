package com.cg.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import com.cg.bean.*;
import com.cg.exception.InsufficientFundException;
import com.cg.service.*;

public class MyWallet {

	public static void main(String[] args) throws IOException, InsufficientFundException, SQLException {
		AccountService service = new AccountService();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String choice = "";
		while (true) {
			System.out.println("=========MENU============");
			System.out.println("1: Create new Account");
			System.out.println("2 Print all Account");
			System.out.println("3 Withdraw");
			System.out.println("4 Deposit");
			System.out.println("5 Fund Transfer");
			System.out.println("6 Delete Account");
			System.out.println("7 Exit");
			System.out.println("=========================");
			System.out.println("Enter Your Choice");
			choice = br.readLine();

			switch (choice) {
			case "1":
				int id = 0;
				long mb = 0L;
				String ah = "";
				double bal = 0.0;

				// Accepting and validating input for account number.......................
				System.out.println("Enter Account ID : ");
				while (true) {
					String s_id = br.readLine();
					boolean ch1 = Validator.validatedata(s_id, Validator.aidpattern);
					if (ch1 == true) {
						try {
							id = Integer.parseInt(s_id);
							break;
						} catch (NumberFormatException e) {
							System.out.println("Account Number must be numeric. Re-Enter");
						}
					} else {
						System.out.println("Re-Enter. Account Number in 3 digits");
					}
				} // end of while.................

				// Accepting and validate input for mobile number
				System.out.println("Enter Mobile Number : ");
				while (true) {
					String s_mb = br.readLine();
					boolean ch1 = Validator.validatedata(s_mb, Validator.mobilepattern);
					if (ch1 == true) {
						try {
							mb = Long.parseLong(s_mb);
							break;
						} catch (NumberFormatException e) {
							System.out.println("Mobile Number must be numeric. Re-Enter");
						}
					} else {
						System.out.println("Re-Enter, Mobile Number must be of 10 digits");
					}
				} // end of while for mobile

				// accepting and validating account holder
				System.out.println("Enter Account Holder Name:-");
				while (true) {
					String s_nm = br.readLine();
					boolean ch2 = Validator.validatedata(s_nm, Validator.namepattern);
					if (ch2 == true) {
						ah = s_nm;
						break;
					} else {
						System.out.println("Re-Enter Name. Name should be in format of Amit Shah");
					}
				} // end of while........

				// accepting and validating account balance
				System.out.println("Enter Balance:-");
				while (true) {
					String s_bal = br.readLine();
					boolean ch3 = Validator.validatedata(s_bal, Validator.balancepattern);
					if (ch3 == true) {
						try {
							bal = Double.parseDouble(s_bal);
							break;
						} catch (NumberFormatException e) {
							System.out.println("Invalid Amount please enter again");
						}
					} else {
						System.out.println("Re Enter Amount. Should not be less then 1000 and in format 0000.00");
					}
				}

				Account ob = new Account(id, mb, ah, bal);

				// calling addAccount method..........
				service.addAccount(ob);
				System.out.println("Account Created");

				break;

			case "2":
				// For displaying all account........

				service.getAllAccount();

				break;
			case "3":
				// for withdraw........

				System.out.println("Enter Registered Account ID: ");
				String s_no = br.readLine();
				id = Integer.parseInt(s_no);
				service.findAccount(id);

				System.out.println("Enter amount to  be withdraw :");

				while (true) {
					String s_amt = br.readLine();
					bal = Double.parseDouble(s_amt);
					if (bal > 0) {

						try {
							service.withdraw(id, bal);
							break;
						} catch (InsufficientFundException e) {

							System.out.println("Invalid Amount.Re Enter Amount.");
						}
					} else {
						System.out.println("Invalid Amount.Re Enter Amount.");
					}
				}
				break;

			case "4":
				// for deposit.........

				System.out.println("Enter Registered Account ID: ");
				String s_no1 = br.readLine();
				id = Integer.parseInt(s_no1);
				service.findAccount(id);

				System.out.println("Enter amount to deposit : ");

				while (true) {
					String s_amt = br.readLine();
					bal = Double.parseDouble(s_amt);
					if (bal > 0) {
						service.deposit(id, bal);
						break;
					} else {
						System.out.println("Invalid Amount.Re Enter Amount.");
					}
				}
				break;

			case "5":
				// For fund transfer..........
				System.out.println("Enter account id from which you want to transfer fund");
				String s_id1 = br.readLine();
				id = Integer.parseInt(s_id1);
				service.findAccount(id);

				System.out.println("Enter account id to which you want to transfer fund");
				String s_id2 = br.readLine();
				int id1 = Integer.parseInt(s_id2);
				service.findAccount(id1);

				System.out.println("Enter Amount : ");

				while (true) {
					String s_bal3 = br.readLine();
					bal = Double.parseDouble(s_bal3);
					if (bal > 0) {
						service.TransferMoney(id, id1, bal);
						break;
					} else {
						System.out.println("Invalid Amount.Re Enter Amount.");
					}
				}
				break;

			case "6":
				// For deleting Account
				System.out.println("Enter Account Id which you want to delete : ");
				String s_id3 = br.readLine();
				int id3 = Integer.parseInt(s_id3);
				service.deleteAccount(id3);
				break;

			case "7":
				// Exiting
				System.out.println("Exiting Program");

				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice");
			}
		} // end of menu...........

	}

}
