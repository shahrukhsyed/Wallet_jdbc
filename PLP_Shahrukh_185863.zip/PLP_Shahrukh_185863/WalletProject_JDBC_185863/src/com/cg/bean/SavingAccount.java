package com.cg.bean;

public class SavingAccount extends Account {

	private double intrest;
	@SuppressWarnings("unused")
	private final double Min_balance = 1000.00;

	// default constructor
	public SavingAccount() {
		// TODO Auto-generated constructor stub
	}

	// parameterized constructor
	public SavingAccount(int aid, int mobile, String accountholder, double balance) {
		super(aid, mobile, accountholder, balance);
	}

	// getters and setters
	public double getIntrest() {
		return intrest;
	}

	public void setIntrest(double intrest) {
		this.intrest = super.getBalance() * 0.04;
	}

	// to string method
	@Override
	public String toString() {
		return super.toString() + "SavingAccount [intrest=" + intrest + "]";
	}

}
