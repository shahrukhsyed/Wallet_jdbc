import { Component } from "@angular/core";
import { AccountService } from './app.accountService';
import { Account } from "./models/Account";
import { DepositAndWithdraw } from "./models/DepositAndWithdraw";
import { Router } from "@angular/router";
@Component({
    selector: 'withdraw',
    templateUrl: 'withdraw.html'
})



export class WithdrawAccountComponent {
    constructor(private service: AccountService,public router:Router) { }
    model: DepositAndWithdraw =
        {
            id: 0,
            amount: 0
        }

    withdraw() {
        this.service.withdraw(this.model).subscribe(
            res => console.log(res)
        )
        this.router.navigate(['show']);
    }

}