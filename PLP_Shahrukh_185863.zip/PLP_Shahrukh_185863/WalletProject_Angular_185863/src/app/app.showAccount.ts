import { Component, } from "@angular/core";
import { AccountService } from './app.accountService';
import { Account } from './models/Account';

@Component({
    selector: 'show-account',
    templateUrl: 'showaccount.html'
})

export class ShowAccountComponent {
    constructor(private service: AccountService) { }
    acc: Account[] = [];
    ngOnInit(): void {
        this.service.getaccount().subscribe(
            res => {
                this.acc = res

            },
            err => {
                alert("Error has occurred")
            }
        )
    }




}