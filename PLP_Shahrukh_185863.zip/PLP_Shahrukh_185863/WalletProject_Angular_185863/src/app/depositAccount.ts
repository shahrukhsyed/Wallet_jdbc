import { Component } from "@angular/core";
import { AccountService } from './app.accountService';
import { Account } from "./models/Account";
import { DepositAndWithdraw } from "./models/DepositAndWithdraw";
import { Router } from "@angular/router";
@Component({
    selector: 'deposit',
    templateUrl: 'deposit.html'
})



export class DepositAccountComponent {
    constructor(private service: AccountService,public router:Router) { }
    model: DepositAndWithdraw =
        {
            id: 0,
            amount: 0
        }
    deposit() {
        this.service.deposit(this.model).subscribe(
            res => console.log(res)
        )
        this.router.navigate(['show']);
    }
}