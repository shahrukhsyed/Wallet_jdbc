import { Component, OnInit } from "@angular/core";
import { AccountService } from './app.accountService';
import { Account } from "./models/Account";
import { Router } from "@angular/router";
@Component({
    selector: 'add-account',
    templateUrl: 'addaccount.html'
})


export class AddAccountComponent implements OnInit {

    id: number;
    phone: string;
    accountHolder: string;
    balance: number;
    acc: Account
    constructor(private service: AccountService,private router:Router) { }
    ngOnInit() { }

    save() {

        var account: Account = new Account(this.id, this.phone, this.accountHolder, this.balance);
        console.log(account);
        this.service.createAccount(account).subscribe(
            res => {
                this.acc = res
            }
        );
        
    }
    chng = false;
    change() {
        this.chng = true;
        this.router.navigate(['show']);
    }
}