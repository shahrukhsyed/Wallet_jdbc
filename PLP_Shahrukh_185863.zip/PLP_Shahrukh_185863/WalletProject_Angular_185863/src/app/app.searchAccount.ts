import { Component } from "@angular/core";
import { AccountService } from './app.accountService';
import { Account } from "./models/Account";

@Component({
    selector: 'search-account',
    templateUrl: 'searchaccount.html'
})



export class SearchAccountComponent {
    acc: Account
    constructor(private service: AccountService) { }
    id: number;
    chng = false;
    change() {
        this.chng = true;
    }
    finddata() {
        console.log(this.id)
        this.service.findaccount(this.id).subscribe(
            res => {
                this.acc = res
            },
            err => {
                alert("Error has occurred")
            }
        )
    }
}