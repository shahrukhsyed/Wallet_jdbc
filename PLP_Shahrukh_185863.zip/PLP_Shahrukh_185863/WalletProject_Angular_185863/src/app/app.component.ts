﻿import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';



@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent {

}