import { Component } from "@angular/core";
import { AccountService } from './app.accountService';
import { Account } from "./models/Account";
import { DepositAndWithdraw } from "./models/DepositAndWithdraw";
import { TransferModel } from './models/TransferModel';
import { Router } from "@angular/router";
@Component({
    selector: 'transfer',
    templateUrl: 'transfer.html'
})
export class TransferAccountComponent {
    constructor(private service: AccountService,public router:Router) { }
    model: TransferModel =
        {
            id1: 0,
            id2: 0,
            amount: 0
        }
    transfer() {
        this.service.transfer(this.model).subscribe(
            res => console.log(res)
        )
        this.router.navigate(['show']);
    }
}