import { Component } from "@angular/core";
import { AccountService } from './app.accountService';
import { Account } from './models/Account';
import { Router } from "@angular/router";

@Component({
    selector: 'delete',
    templateUrl: 'delete.html'
})

export class DeleteAccountComponent {

    id: number
    acc: Account
    constructor(private service: AccountService,private router:Router) { }
    Delete() {
        this.service.delete(this.id).subscribe(
            res => {
                this.acc = res
            }
        )
       
    }

    chng = false;

    change() {
        this.chng = true;
        this.router.navigate(['show']);
    }

}