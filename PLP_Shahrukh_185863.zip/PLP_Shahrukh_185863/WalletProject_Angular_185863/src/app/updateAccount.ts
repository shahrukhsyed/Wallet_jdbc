import { Component } from "@angular/core";
import { AccountService } from './app.accountService';
import { Account } from './models/Account';
import { Router } from "@angular/router";

@Component({
    selector: 'update',
    templateUrl: 'update.html'
})

export class UpdateAccountComponent {
    model: Account = {
        id: 0,
        phone: '',
        accountHolder: "",
        balance: 0.0
    }

    acc: Account
    constructor(private service: AccountService,public router:Router) { }
    update() {
        this.service.update(this.model, this.model.id).subscribe(
            res => {
            this.acc = res
            }

        )
        this.router.navigate(['show']);
    }
    chng = false;
    change() {
        this.chng = true;
    }



}